from serial.tools.miniterm import main

print(
    """-------------------------------------------------------------------------------
 If you can't see the prompt, then try ENTER, Ctrl+C or Ctrl+B.
 Exit with Ctrl+T or simply close the terminal window.
-------------------------------------------------------------------------------"""
)
main()
