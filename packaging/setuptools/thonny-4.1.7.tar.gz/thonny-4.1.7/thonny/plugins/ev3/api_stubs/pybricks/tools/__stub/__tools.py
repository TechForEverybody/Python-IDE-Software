def wait(time: int):
    """
    Pauses the user program for a specified amount of time.

    Args:
        time (int): How long to wait in milliseconds.
    """
    ...
