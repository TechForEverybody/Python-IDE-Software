from thonny import launch, report_time
from thonny.flask_app import startFlaskApp
from thonny.login_validator import LoginApp, openLoginScreen


def main():
    startFlaskApp()
    report_time("Before launch")
    launch()


loginApp = LoginApp()
print(loginApp.isLoggedIn())
if loginApp.isLoggedIn():
    main()
else:
    openLoginScreen(successFunction=main)
